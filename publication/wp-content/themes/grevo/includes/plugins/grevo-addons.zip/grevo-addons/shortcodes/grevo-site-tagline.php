<?php
// [grevo-site-tagline]
if( !function_exists('themesion_grevo_sc_site_tagline') ){
function themesion_grevo_sc_site_tagline( $atts, $content=NULL ){
	return get_bloginfo('description');
}
}
add_shortcode( 'grevo-site-tagline', 'themesion_grevo_sc_site_tagline' );