<?php
// [grevo-site-title]
if( !function_exists('themesion_grevo_sc_site_title') ){
function themesion_grevo_sc_site_title( $atts, $content=NULL ){
	return get_bloginfo('name');
}
}
add_shortcode( 'grevo-site-title', 'themesion_grevo_sc_site_title' );