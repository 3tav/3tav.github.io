<?php
// [grevo-site-url]
if( !function_exists('themesion_grevo_sc_site_url') ){
function themesion_grevo_sc_site_url( $atts, $content=NULL ){
	return site_url();
}
}
add_shortcode( 'grevo-site-url', 'themesion_grevo_sc_site_url' );