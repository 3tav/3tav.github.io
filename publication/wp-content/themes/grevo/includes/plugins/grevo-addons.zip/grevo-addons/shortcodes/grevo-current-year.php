<?php
// [grevo-current-year]
if( !function_exists('themesion_grevo_sc_current_year') ){
function themesion_grevo_sc_current_year( $atts, $content=NULL ){
	return date("Y");
}
}
add_shortcode( 'grevo-current-year', 'themesion_grevo_sc_current_year' );